<?php

return [

    'failed' => 'As credenciais informadas estão incorretas.',
    'password' => 'A senha informada está incorreta.',
    'throttle' => 'Muitas tentativas de login. Tente novamente em :seconds segundos.',

];
