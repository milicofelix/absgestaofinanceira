import { Link } from '@inertiajs/react';

export default function ResponsiveNavLink({ active = false, className = '', children, ...props }) {
  return (
    <Link
      {...props}
      className={`flex w-full items-start border-l-4 py-2 pe-4 ps-3 ${
        active
          ? 'border-emerald-500 bg-emerald-50 text-emerald-800 focus:border-emerald-700 focus:bg-emerald-100 focus:text-emerald-900'
          : 'border-transparent text-gray-700 hover:border-gray-300 hover:bg-gray-50 hover:text-gray-900 focus:border-gray-300 focus:bg-gray-50 focus:text-gray-900'
      } text-base font-semibold transition duration-150 ease-in-out focus:outline-none ${className}`}
    >
      {children}
    </Link>
  );
}
